<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Bajas extends Model
{
    //
}
