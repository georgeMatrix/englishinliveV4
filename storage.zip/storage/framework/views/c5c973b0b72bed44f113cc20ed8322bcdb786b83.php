<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('include.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="container">
        <div class="row">
            <div class="col-lg-2 col-md-2 col-md-2 col-xs-2 offset-xl-10 offset-md-10 offset-xs-10 mb-3">
                <a class="btn btn-success btn-block" href="<?php echo e(route('colegiaturas.create')); ?>" >NUEVO</a>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12 col-md-12 col-xl-12">
                <div class="table-responsive content-loader">
                    <table class="table table-hover table-sm table-striped">
                        <thead class="table-primary">
                        <tr>
                            <th>NO.</th>
                            <th>COLEGIATURAS</th>
                            <th>NOMBRE_DEL_ALUMNO</th>
                            <th>FECHA</th>
                            <th>INSCRIPCION</th>
                            <th>LIBROS</th>
                            <th>CERTIFICADO SEP</th>
                            <th>EDITAR</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $colegiaturas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $colegiatura): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($colegiatura->id); ?></td>
                                <td><?php echo e($colegiatura->colegiaturas); ?></td>
                                <td><?php echo e($colegiatura->nombreAlumno); ?></td>
                                <td><?php echo e($colegiatura->fecha); ?></td>
                                <td><?php echo e($colegiatura->inscripcion); ?></td>
                                <td><?php echo e($colegiatura->libros); ?></td>
                                <td><?php echo e($colegiatura->certificadoSep); ?></td>
                                <td><a href="<?php echo e(route('colegiaturas.edit', $colegiatura->id)); ?>" class="btn btn-info">Editar</a></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <?php echo e($colegiaturas->render()); ?>

                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>