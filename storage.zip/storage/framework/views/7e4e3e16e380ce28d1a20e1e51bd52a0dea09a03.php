<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('include.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="text-center title">CERTIFICACIONES</h1>
            </div>
            <div class="col-lg-2 col-md-2 col-md-2 col-xs-2 offset-xl-10 offset-md-10 offset-xs-10 mb-3">
                <a class="btn btn-success btn-block" href="<?php echo e(route('certificaciones.create')); ?>" >NUEVO</a>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12 col-md-12 col-xl-12">
                <div class="table-responsive content-loader">
                    <table class="table table-hover table-sm table-striped">
                        <thead class="table-primary">
                        <tr>
                            <th>NO.</th>
                            <th>NOMBRE</th>
                            <th>FECHA_DE_CERTIFICACION</th>
                            <th>ENTIDAD</th>
                            <th>RESULTADO</th>
                            <th>RESULTADO_GENERAL</th>
                            <th>CEFR_LEVEL</th>
                            <th>READING_SCORE</th>
                            <th>WRITING_SCORE</th>
                            <th>LISTENING_SCORE</th>
                            <th>SPEAKING_SCORE</th>
                            <th>CAMBRIDGE_ENGLISH_SCALE</th>
                            <th>CERTIFICATE_RESULT</th>
                            <th>EDITAR</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $certificaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $certificacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($certificacion->id); ?></td>
                                <td><?php echo e($certificacion->nombre); ?></td>
                                <td><?php echo e($certificacion->fechaCertificacion); ?></td>
                                <td><?php echo e($certificacion->entidad); ?></td>
                                <td><?php echo e($certificacion->resultado); ?></td>
                                <td><?php echo e($certificacion->resultadoGeneral); ?></td>
                                <td><?php echo e($certificacion->cefrLevel); ?></td>
                                <td><?php echo e($certificacion->readingScore); ?></td>
                                <td><?php echo e($certificacion->writingScore); ?></td>
                                <td><?php echo e($certificacion->listeningScore); ?></td>
                                <td><?php echo e($certificacion->speakingScore); ?></td>
                                <td><?php echo e($certificacion->cambridgeEnglishScale); ?></td>
                                <td><?php echo e($certificacion->certificateResult); ?></td>
                                <td><a href="<?php echo e(route('certificaciones.edit', $certificacion->id)); ?>" class="btn btn-info">Editar</a></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <?php echo e($certificaciones->render()); ?>

                    </table>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>