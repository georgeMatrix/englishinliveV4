<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('include.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-xl-12 mb-4">
                <form class="user" action="<?php echo e(url('baseDeDatos/'.$baseDeDatos->id)); ?>" method="post">
                    <?php echo e(csrf_field()); ?>

                    <?php echo e(method_field('PATCH')); ?>

                    <div class="form-group row">
                        <div class="col-sm-6 mb-3 mb-sm-0">
                            <input type="text" class="form-control form-control-user" value="<?php echo e($baseDeDatos->grado); ?>" id="grado" name="grado" placeholder="Grado">
                        </div>
                        <div class="col-sm-6">
                            <input type="text" class="form-control form-control-user" value="<?php echo e($baseDeDatos->grupo); ?>" id="grupo" name="grupo" placeholder="Grupo">
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-sm-6 mb-3 mb-sm-0">
                            <input type="text" class="form-control form-control-user" value="<?php echo e($baseDeDatos->escolaridad); ?>" id="escolaridad" name="escolaridad" placeholder="Escolaridad">
                        </div>
                        <div class="col-sm-6">
                            <input type="text" class="form-control form-control-user" value="<?php echo e($baseDeDatos->no_control); ?>" id="no_control" name="no_control" placeholder="No. de Control">
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-sm-6 mb-3 mb-sm-0">
                            <input type="text" class="form-control form-control-user" value="<?php echo e($baseDeDatos->matricula); ?>" id="matricula" name="matricula" placeholder="Matricula">
                        </div>
                        <div class="col-sm-6">
                            <input type="text" class="form-control form-control-user" value="<?php echo e($baseDeDatos->edad); ?>" id="edad" name="edad" placeholder="Edad">
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-sm-6 mb-3 mb-sm-0">
                            <input type="text" class="form-control form-control-user" value="<?php echo e($baseDeDatos->incorporados); ?>" id="incorporados" name="incorporados" placeholder="Incorporados">
                        </div>
                        <div class="col-sm-6">
                            <input type="text" class="form-control form-control-user" value="<?php echo e($baseDeDatos->nivel); ?>" id="nivel" name="nivel" placeholder="Nivel">
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-sm-6 mb-3 mb-sm-0">
                            <input type="text" class="form-control form-control-user" value="<?php echo e($baseDeDatos->horario_sep); ?>" id="horario_sep" name="horario_sep" placeholder="Horario Sep">
                        </div>
                        <div class="col-sm-6">
                            <input type="text" class="form-control form-control-user" value="<?php echo e($baseDeDatos->horario); ?>" id="horario" name="horario" placeholder="Horario">
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-sm-6 mb-3 mb-sm-0">
                            <input type="text" class="form-control form-control-user" value="<?php echo e($baseDeDatos->nombre_completo); ?>" id="nombre_completo" name="nombre_completo" placeholder="Nombre Completo">
                        </div>
                        <div class="col-sm-6">
                            <input type="text" class="form-control form-control-user" value="<?php echo e($baseDeDatos->fecha_de_ingreso); ?>" id="fecha_de_ingreso" name="fecha_de_ingreso" placeholder="Fecha de Ingreso">
                        </div>
                    </div>

                    <div class="form-group row">
                        <div class="col-sm-6 mb-3 mb-sm-0">
                            <input type="text" class="form-control form-control-user" value="<?php echo e($baseDeDatos->telefono_casa_oficina); ?>" id="telefono_casa_oficina" name="telefono_casa_oficina" placeholder="Telefono Casa u Oficina">
                        </div>
                        <div class="col-sm-6">
                            <input type="text" class="form-control form-control-user" value="<?php echo e($baseDeDatos->celular); ?>" id="celular" name="celular" placeholder="Celular">
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-sm-6 mb-3 mb-sm-0">
                            <input type="text" class="form-control form-control-user" value="<?php echo e($baseDeDatos->facebook); ?>" id="facebook" name="facebook" placeholder="Facebook">
                        </div>
                        <div class="col-sm-6">
                            <input type="text" class="form-control form-control-user" value="<?php echo e($baseDeDatos->fecha_de_nacimiento); ?>" id="fecha_de_nacimiento" name="fecha_de_nacimiento" placeholder="Fecha de Nacimiento">
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-sm-6 mb-3 mb-sm-0">
                            <input type="text" class="form-control form-control-user" value="<?php echo e($baseDeDatos->edad); ?>" id="edad" name="edad" placeholder="Edad">
                        </div>
                        <div class="col-sm-6">
                            <input type="text" class="form-control form-control-user" value="<?php echo e($baseDeDatos->direccion); ?>" id="direccion" name="direccion" placeholder="Direccion">
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-sm-6 mb-3 mb-sm-0">
                            <input type="text" class="form-control form-control-user" value="<?php echo e($baseDeDatos->municipio); ?>" id="municipio" name="municipio" placeholder="Municipio">
                        </div>
                        <div class="col-sm-6">
                            <input type="text" class="form-control form-control-user" value="<?php echo e($baseDeDatos->email); ?>" id="email" name="email" placeholder="Email">
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-sm-6 mb-3 mb-sm-0">
                            <input type="text" class="form-control form-control-user" value="<?php echo e($baseDeDatos->grado_estudios); ?>" id="grado_estudios" name="grado_estudios" placeholder="Grado De Estudios">
                        </div>
                        <div class="col-sm-6">
                            <input type="text" class="form-control form-control-user" value="<?php echo e($baseDeDatos->como_te_enteraste); ?>" id="como_te_enteraste" name="como_te_enteraste" placeholder="Como te Enteraste">
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-sm-6 mb-3 mb-sm-0">
                            <button class="btn btn-primary" type="submit">Guardar Datos</button>
                        </div>
                        <div class="col-md-2">
                            <a class="btn btn-danger" href="<?php echo e(url('baseDeDatos')); ?>"><i class="fas fa-times"></i> Cancelar</a>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>