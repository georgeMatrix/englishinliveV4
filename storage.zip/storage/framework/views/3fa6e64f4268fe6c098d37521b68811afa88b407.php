<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('include.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-xl-12 mb-4">
                <form class="user" action="<?php echo e(url('colegiaturas/'.$colegiatura->id)); ?>" method="post">
                        <?php echo e(csrf_field()); ?>

                        <?php echo e(method_field('PATCH')); ?>

                    <div class="form-group row">
                        <div class="col-sm-6 mb-3 mb-sm-0">
                            <input type="text" class="form-control form-control-user" value="<?php echo e($colegiatura->colegiaturas); ?>" id="colegiaturas" name="colegiaturas" placeholder="colegiaturas">
                        </div>
                        <div class="col-sm-6">
                            <input type="text" class="form-control form-control-user" value="<?php echo e($colegiatura->fecha); ?>" id="fecha" name="fecha" placeholder="fecha">
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-sm-6 mb-3 mb-sm-0">
                            <input type="text" class="form-control form-control-user" value="<?php echo e($colegiatura->inscripcion); ?>" id="inscripcion" name="inscripcion" placeholder="inscripcion">
                        </div>
                        <div class="col-sm-6">
                            <input type="text" class="form-control form-control-user" value="<?php echo e($colegiatura->libros); ?>" id="libros" name="libros" placeholder="libros">
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-sm-6 mb-3 mb-sm-0">
                            <input type="text" class="form-control form-control-user" value="<?php echo e($colegiatura->certificadoSep); ?>" id="certificadoSep" name="certificadoSep" placeholder="certificadoSep">
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-sm-6 mb-3 mb-sm-0">
                            <button class="btn btn-primary" type="submit">Actualizar Datos</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>