<a href="<?php echo e(route('calificaciones.edit', $id)); ?>" class="btn btn-primary btn-sm"><i class="far fa-edit"></i></a>
