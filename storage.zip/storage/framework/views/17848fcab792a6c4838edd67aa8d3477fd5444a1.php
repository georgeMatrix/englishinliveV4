<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(route("clientePrueba.store")); ?>" method="post">
        
        <input type="text" placeholder="nombre" name="nombre">
        <input type="text" placeholder="apellido" name="apellido">
        <input type="text" placeholder="edad" name="edad">
        <input type="submit">
    </form>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>