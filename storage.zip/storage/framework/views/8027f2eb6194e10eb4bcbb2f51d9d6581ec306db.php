<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('include.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="text-center title">CALIFICACIONES</h1>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-2 col-md-2 col-md-2 col-xs-2 offset-xl-8 offset-md-8 offset-xs-8 mb-3">
                <a class="btn btn-success btn-block" href="<?php echo e(route('calificaciones.create')); ?>" >NUEVO</a>
            </div>
            <div class="col-lg-2 col-md-2 col-md-2 col-xs-2 mb-3">
                <a class="btn btn-success btn-block" href="#" >CATALOGO</a>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12 col-md-12 col-xl-12">
                <div class="table-responsive content-loader">
                    <table class="table table-hover table-sm table-striped">
                        <thead class="table-primary">
                        <tr>
                            <th>NO.</th>
                            <th>NO._DE_CONTROL</th>
                            <th>MAESTRO</th>
                            <th>NOMBRE_COMPLETO_DEL_ALUMNO</th>
                            <th>1ST_TEST</th>
                            <th>2DO_TEST</th>
                            <th>3ER_TEST</th>
                            <th>WORKBOOK</th>
                            <th>PLATAFORMA_Y_TAREAS</th>
                            <th>FINAL_SCORE</th>
                            <th>PARTICIPATION</th>
                            <th>UNDERSTANDING_OF_CONCEPTS_PRINCIPLES</th>
                            <th>APPLICATION_OF_CONCEPTS</th>
                            <th>PRESENTATION_SKILL</th>
                            <th>TEST_SCORE</th>
                            <th>1ST_TEST</th>
                            <th>2DO_TEST</th>
                            <th>3ER_TEST</th>
                            <th>PLATAFORMA_Y_TAREAS</th>
                            <th>FINAL_SCORE</th>
                            <th>PARTICIPATION</th>
                            <th>UNDERSTANDING_OF_CONCEPTS_PRINCIPLES</th>
                            <th>APPLICATION_OF_CONCEPTS</th>
                            <th>PRESENTATION_SKILL</th>
                            <th>TEST_SCORE</th>

                            <th>1ST_TEST</th>
                            <th>2DO_TEST</th>
                            <th>3ER_TEST</th>
                            <th>PLATAFORMA_Y_TAREAS</th>
                            <th>FINAL_SCORE</th>
                            <th>PARTICIPATION</th>
                            <th>UNDERSTANDING_OF_CONCEPTS_PRINCIPLES</th>
                            <th>APPLICATION_OF_CONCEPTS</th>
                            <th>PRESENTATION_SKILL</th>
                            <th>TEST_SCORE</th>

                            <th>1ST_TEST</th>
                            <th>2DO_TEST</th>
                            <th>3ER_TEST</th>
                            <th>PLATAFORMA_Y_TAREAS</th>
                            <th>FINAL_SCORE</th>
                            <th>PARTICIPATION</th>
                            <th>UNDERSTANDING_OF_CONCEPTS_PRINCIPLES</th>
                            <th>APPLICATION_OF_CONCEPTS</th>
                            <th>PRESENTATION_SKILL</th>
                            <th>TEST_SCORE</th>
                            <th>EDITAR</th>
                        </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $calificaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $calificacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($calificacion->id); ?></td>
                                <td><?php echo e($calificacion->noControl); ?></td>
                                <td><?php echo e($calificacion->maestro); ?></td>
                                <td><?php echo e($calificacion->alumno); ?></td>

                                <td><?php echo e($calificacion->icInicial1stTest); ?></td>
                                <td><?php echo e($calificacion->icInicial2stTest); ?></td>
                                <td><?php echo e($calificacion->icInicial3stTest); ?></td>
                                <td><?php echo e($calificacion->workbook); ?></td>
                                <td><?php echo e($calificacion->icInicialPlataformaYtareas); ?></td>
                                <td><?php echo e($calificacion->icInicialFinalScore); ?></td>
                                <td><?php echo e($calificacion->icInicialParticipation); ?></td>
                                <td><?php echo e($calificacion->icInicialUnderstanding); ?></td>
                                <td><?php echo e($calificacion->icInicialApplication); ?></td>
                                <td><?php echo e($calificacion->icInicialPresentation); ?></td>
                                <td><?php echo e($calificacion->icInicialTestScore); ?></td>

                                <td><?php echo e($calificacion->icbSuperior1stTest); ?></td>
                                <td><?php echo e($calificacion->icbSuperior2stTest); ?></td>
                                <td><?php echo e($calificacion->icbSuperior3stTest); ?></td>
                                <td><?php echo e($calificacion->icbSuperiorPlataformaYtareas); ?></td>
                                <td><?php echo e($calificacion->icbSuperiorFinalScore); ?></td>
                                <td><?php echo e($calificacion->icbSuperiorParticipation); ?></td>
                                <td><?php echo e($calificacion->icbSuperiorUnderstanding); ?></td>
                                <td><?php echo e($calificacion->icbSuperiorApplication); ?></td>
                                <td><?php echo e($calificacion->icbSuperiorPresentation); ?></td>
                                <td><?php echo e($calificacion->icbSuperiorTestScore); ?></td>

                                <td><?php echo e($calificacion->icpIntermedio1stTest); ?></td>
                                <td><?php echo e($calificacion->icpIntermedio2stTest); ?></td>
                                <td><?php echo e($calificacion->icpIntermedio3stTest); ?></td>
                                <td><?php echo e($calificacion->icpIntermedioPlataformaYtareas); ?></td>
                                <td><?php echo e($calificacion->icpIntermedioFinalScore); ?></td>
                                <td><?php echo e($calificacion->icpIntermedioParticipation); ?></td>
                                <td><?php echo e($calificacion->icpIntermedioUnderstanding); ?></td>
                                <td><?php echo e($calificacion->icpIntermedioApplication); ?></td>
                                <td><?php echo e($calificacion->icpIntermedioPresentation); ?></td>
                                <td><?php echo e($calificacion->icpIntermedioTestScore); ?></td>

                                <td><?php echo e($calificacion->icIntermedio1stTest); ?></td>
                                <td><?php echo e($calificacion->icIntermedio2stTest); ?></td>
                                <td><?php echo e($calificacion->icIntermedio3stTest); ?></td>
                                <td><?php echo e($calificacion->icIntermedioPlataformaYtareas); ?></td>
                                <td><?php echo e($calificacion->icIntermedioFinalScore); ?></td>
                                <td><?php echo e($calificacion->icIntermedioParticipation); ?></td>
                                <td><?php echo e($calificacion->icIntermedioUnderstanding); ?></td>
                                <td><?php echo e($calificacion->icIntermedioApplication); ?></td>
                                <td><?php echo e($calificacion->icIntermedioPresentation); ?></td>
                                <td><?php echo e($calificacion->icIntermedioTestScore); ?></td>
                                <td><a href="<?php echo e(route('calificaciones.edit', $calificacion->id)); ?>" class="btn btn-info">Editar</a></td>

                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>