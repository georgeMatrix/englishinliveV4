<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('include.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-xl-12 mb-4">
                <form class="user" action="<?php echo e(url('controlEscolar/'.$controlEscolar->id)); ?>" method="post">
                    <?php echo e(csrf_field()); ?>

                    <?php echo e(method_field('PATCH')); ?>

                    <div class="form-group row">
                        <div class="col-sm-6 mb-3 mb-sm-0">
                            <input type="text" class="form-control form-control-user" value="<?php echo e($controlEscolar->grupo); ?>" id="grupo" name="grupo" placeholder="Grupo">
                        </div>
                        <div class="col-sm-6">
                            <input type="text" class="form-control form-control-user" value="<?php echo e($controlEscolar->escolaridad); ?>" id="escolaridad" name="escolaridad" placeholder="Escolaridad">
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-sm-6 mb-3 mb-sm-0">
                            <input type="text" class="form-control form-control-user" value="<?php echo e($controlEscolar->noControl); ?>" id="noControl" name="noControl" placeholder="No. de control">
                        </div>
                        <div class="col-sm-6">
                            <input type="text" class="form-control form-control-user" value="<?php echo e($controlEscolar->cicloEscolar); ?>" id="cicloEscolar" name="cicloEscolar" placeholder="Ciclo escolar">
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-sm-6 mb-3 mb-sm-0">
                            <input type="text" class="form-control form-control-user" value="<?php echo e($controlEscolar->edad); ?>" id="edad" name="edad" placeholder="Edad">
                        </div>
                        <div class="col-sm-6">
                            <input type="text" class="form-control form-control-user" value="<?php echo e($controlEscolar->incorporados); ?>" id="incorporados" name="incorporados" placeholder="Incorporados">
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-sm-6 mb-3 mb-sm-0">
                            <input type="text" class="form-control form-control-user" value="<?php echo e($controlEscolar->sexo); ?>" id="sexo" name="sexo" placeholder="Sexo">
                        </div>
                        <div class="col-sm-6 mb-3 mb-sm-0">
                            <select name="niveles" id="niveles" class="form-control form-control-user">
                                <option value="">Seleccione una opción</option>
                                <option value="1" <?php echo e($controlEscolar->niveles == 1 ? 'selected':''); ?>>Ingles Comunicativo</option>
                                <option value="2" <?php echo e($controlEscolar->niveles == 2 ? 'selected':''); ?>>Ingles Comunicativo Superior</option>
                                <option value="3" <?php echo e($controlEscolar->niveles == 3 ? 'selected':''); ?>>Ingles Preintermedio</option>
                                <option value="4" <?php echo e($controlEscolar->niveles == 4 ? 'selected':''); ?>>Ingles Intermedio</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-sm-6 mb-3 mb-sm-0">
                            <input type="text" class="form-control form-control-user" value="<?php echo e($controlEscolar->maestro); ?>" id="maestro" name="maestro" placeholder="Maestro">
                        </div>
                        <div class="col-sm-6">
                            <input type="text" class="form-control form-control-user" value="<?php echo e($controlEscolar->horarioSep); ?>" id="horarioSep" name="horarioSep" placeholder="Horario SEP">
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-sm-6 mb-3 mb-sm-0">
                            <input type="text" class="form-control form-control-user" value="<?php echo e($controlEscolar->curp); ?>" id="curp" name="curp" placeholder="CURP">
                        </div>
                        <div class="col-sm-6">
                            <input type="text" class="form-control form-control-user" value="<?php echo e($controlEscolar->horario); ?>" id="horario" name="horario" placeholder="Horario">
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-sm-6 mb-3 mb-sm-0">
                            <input type="text" class="form-control form-control-user" value="<?php echo e($controlEscolar->modulosAcreditados); ?>" id="modulosAcreditados" name="modulosAcreditados" placeholder="Modulos Acreditados">
                        </div>
                        <div class="col-sm-6">
                            <input type="text" class="form-control form-control-user" value="<?php echo e($controlEscolar->nombreCompleto); ?>" id="nombreCompleto" name="nombreCompleto" placeholder="Nombre Completo">
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-md-2">
                            <button class="btn btn-primary" type="submit">Guardar Datos</button>
                        </div>
                        <div class="col-md-2">
                            <a class="btn btn-danger" href="<?php echo e(url('controlEscolar')); ?>"><i class="fas fa-times"></i> Cancelar</a>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>