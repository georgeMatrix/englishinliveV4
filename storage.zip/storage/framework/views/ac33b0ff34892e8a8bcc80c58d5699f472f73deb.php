<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('include.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="text-center title">BASE DE DATOS</h1>
            </div>
            <div class="col-lg-2 col-md-2 col-md-2 col-xs-2 offset-xl-10 offset-md-10 offset-xs-10 mb-3">
                <a class="btn btn-success btn-block" href="<?php echo e(route('baseDeDatos.create')); ?>" >NUEVO</a>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12 col-md-12 col-xl-12">
                <div class="table-responsive content-loader">
                    <table class="table table-hover table-sm table-striped">
                        <thead class="table-primary">
                        <tr>
                            <th>NO.</th>
                            <th>GRUPO</th>
                            <th>GRADO</th>
                            <th>ESCOLARIDAD</th>
                            <th>NO._DE_ESCOLARIDAD</th>
                            <th>MATRICULA</th>
                            <th>EDAD</th>
                            <th>INCORPORADOS</th>
                            <th>NIVEL</th>
                            <th>HORARIO_SEP</th>
                            <th>HORARIO</th>
                            <th>NOMBRE_COMPLETO_DEL_ALUMNO</th>
                            <th>FECHA_DE_INGRESO</th>
                            <th>TELEFONO_DE_CASA_OFICINA</th>
                            <th>CELULAR</th>
                            <th>FACEBOOK</th>
                            <th>FECHA_DE_NACIMIENTO</th>
                            <th>EDAD</th>
                            <th>DIRECCION</th>
                            <th>MUNICIPIO</th>
                            <th>EMAIL</th>
                            <th>GRADO_DE_ESTUDIOS</th>
                            <th>COMO_TE_ENTERASTE</th>
                            <th>EDITAR</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $baseDatos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $base): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($base->id); ?></td>
                                <td><?php echo e($base->grado); ?></td>
                                <td><?php echo e($base->grupo); ?></td>
                                <td><?php echo e($base->escolaridad); ?></td>
                                <td><?php echo e($base->no_control); ?></td>
                                <td><?php echo e($base->matricula); ?></td>
                                <td><?php echo e($base->edad); ?></td>
                                <td><?php echo e($base->incorporados); ?></td>
                                <td><?php echo e($base->nivel); ?></td>
                                <td><?php echo e($base->horario_sep); ?></td>
                                <td><?php echo e($base->horario); ?></td>
                                <td><?php echo e($base->nombre_completo); ?></td>
                                <td><?php echo e($base->fecha_de_ingreso); ?></td>
                                <td><?php echo e($base->telefono_casa_oficina); ?></td>
                                <td><?php echo e($base->celular); ?></td>
                                <td><?php echo e($base->facebook); ?></td>
                                <td><?php echo e($base->fecha_de_nacimiento); ?></td>
                                <td><?php echo e($base->edad); ?></td>
                                <td><?php echo e($base->direccion); ?></td>
                                <td><?php echo e($base->municipio); ?></td>
                                <td><?php echo e($base->email); ?></td>
                                <td><?php echo e($base->grado_estudios); ?></td>
                                <td><?php echo e($base->como_te_enteraste); ?></td>
                                <td><a href="<?php echo e(route('baseDeDatos.edit', $base->id)); ?>" class="btn btn-info">Editar</a></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <?php echo e($baseDatos->render()); ?>

                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>