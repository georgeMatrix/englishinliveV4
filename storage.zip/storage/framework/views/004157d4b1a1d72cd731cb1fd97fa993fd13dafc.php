<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('include.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="container">
        <form action="<?php echo e(url('calificaciones/'.$calificacion->id)); ?>" method="post">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-xl-12 mb-4">
                    <?php echo e(csrf_field()); ?>

                    <?php echo e(method_field('PATCH')); ?>

                    <div class="form-group row">
                        <div class="col-lg-12 col-md-12 col-xl-12">
                            <input required type="text" class="form-control form-control-user" value="<?php echo e($calificacion->noControl); ?>" id="noControl" name="noControl" placeholder="No. de Control">
                        </div>
                    </div>

                    <div class="form-group row">
                        <div class="col-sm-6">
                            <input required type="text" class="form-control form-control-user" value="<?php echo e($calificacion->maestro); ?>" id="maestro" name="maestro" placeholder="Maestro">
                        </div>
                        <div class="col-sm-6">
                            <input required type="text" class="form-control form-control-user" value="<?php echo e($calificacion->alumno); ?>" id="alumno" name="alumno" placeholder="Nombre de Alumno">
                        </div>
                    </div>

                </div>
            </div>

            <div class="row">
                <div class="col-md-12">
                    <div role="tabpanel">
                        <!-- Nav tabs -->
                        <ul class="nav nav-tabs">
                            <li class="nav-item">
                                <a href="#tab1" class="nav-link active" aria-controls="tab1" role="tab" data-toggle="tab">Inglés Comunicativo Inicial</a>
                            </li>
                            <li class="nav-item">
                                <a href="#tab2" class="nav-link" aria-controls="tab2" role="tab" data-toggle="tab">Inglés Comunicativo Básico Superior</a>
                            </li>
                            <li class="nav-item">
                                <a href="#tab3" class="nav-link" aria-controls="tab3" role="tab" data-toggle="tab">Inglés Comunicativo Pre Intermedio</a>
                            </li>
                            <li class="nav-item">
                                <a href="#tab4" class="nav-link" aria-controls="tab4" role="tab" data-toggle="tab">Inglés Comunicativo Intermedio</a>
                            </li>

                        </ul>
                        <!-- Tab panes -->
                        <div class="tab-content">
                            <div role="tabpanel" class="tab-pane active" id="tab1">

                                <?php echo e(csrf_field()); ?>

                                <div class="form-group p-3">
                                    <h5>Inglés Comunicativo Inicial</h5>
                                    <div class="form-group row">
                                        <div class="col-sm-4">
                                            <input min="0" max="20" type="number" class="form-control form-control-user" value="<?php echo e($calificacion->icInicial1stTest); ?>" id="icInicial1stTest" name="icInicial1stTest" onfocusout="sumatoria()" placeholder="1st test">
                                        </div>
                                        <div class="col-sm-4">
                                            <input min="0" max="30" type="number" class="form-control form-control-user" value="<?php echo e($calificacion->icInicial2stTest); ?>" id="icInicial2stTest" name="icInicial2stTest" onfocusout="sumatoria()" placeholder="2do test">
                                        </div>
                                        <div class="col-sm-4">
                                            <input min="0" max="30" type="number" class="form-control form-control-user" value="<?php echo e($calificacion->icInicial3stTest); ?>" id="icInicial3stTest" name="icInicial3stTest" onfocusout="sumatoria()" placeholder="3er test">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <div class="col-sm-4 mb-3 mb-sm-0">
                                            <input min="0" max="10" type="number" class="form-control form-control-user" value="<?php echo e($calificacion->icInicialPlataformaYtareas); ?>" id="icInicialPlataformaYtareas" name="icInicialPlataformaYtareas" onfocusout="sumatoria()" placeholder="Plataforma y Tareas">
                                        </div>
                                        <div class="col-sm-4 mb-3 mb-sm-0">
                                            <input min="0" max="10" type="number" class="form-control form-control-user" value="<?php echo e($calificacion->workbook); ?>" id="workbook" name="workbook" onfocusout="sumatoria()" placeholder="Workbook">
                                        </div>
                                        <div class="col-sm-4 mb-3 mb-sm-0">
                                            <input readonly type="number" class="form-control form-control-user" value="<?php echo e($calificacion->icInicialFinalScore); ?>" id="icInicialFinalScore" name="icInicialFinalScore" onfocusout="sumatoria()" placeholder="Final Score">
                                        </div>
                                    </div>

                                    <hr>
                                    <div class="form-group row">
                                        <div class="col-sm-4 mb-3 mb-sm-0">
                                            <input type="text" class="form-control form-control-user" value="<?php echo e($calificacion->icInicialParticipation); ?>" id="icInicialParticipation" name="icInicialParticipation" placeholder="Participation">
                                        </div>
                                        <div class="col-sm-4 mb-3 mb-sm-0">
                                            <input type="text" class="form-control form-control-user" value="<?php echo e($calificacion->icInicialUnderstanding); ?>" id="icInicialUnderstanding" name="icInicialUnderstanding" placeholder="Understanding of concepts principles">
                                        </div>
                                        <div class="col-sm-4 mb-3 mb-sm-0">
                                            <input type="text" class="form-control form-control-user" value="<?php echo e($calificacion->icInicialApplication); ?>" id="icInicialApplication" name="icInicialApplication" placeholder="Application of concepts">
                                        </div>
                                    </div>

                                    <div class="form-group row">
                                        <div class="col-sm-4 mb-3 mb-sm-0">
                                            <input type="text" class="form-control form-control-user" value="<?php echo e($calificacion->icInicialPresentation); ?>" id="icInicialPresentation" name="icInicialPresentation" placeholder="Presentation Skill">
                                        </div>
                                        <div class="col-sm-4 mb-3 mb-sm-0">
                                            <input type="text" class="form-control form-control-user" value="<?php echo e($calificacion->icInicialTestScore); ?>" id="icInicialTestScore" name="icInicialTestScore" placeholder="Test Score">
                                        </div>
                                    </div>

                                    <div class="form-group row">
                                        <div class="col-sm-6 mb-3 mb-sm-0">
                                            <button type="submit" class="btn btn-info" id="inglesComunicativoInicialBtn">Actualizar</button>
                                        </div>
                                    </div>

                                </div>

                            </div>
                            <div role="tabpanel" class="tab-pane" id="tab2">

                                <div class="form-group p-3">
                                    <h5>Inglés Comunicativo Básico Superior</h5>
                                    <div class="form-group row">
                                        <div class="col-sm-4">
                                            <input min="0" max="20" type="number" class="form-control form-control-user" value="<?php echo e($calificacion->icbSuperior1stTest); ?>" id="icbSuperior1stTest" onfocusout="sumatoriaIcBs()" name="icbSuperior1stTest" placeholder="1st test">
                                        </div>
                                        <div class="col-sm-4">
                                            <input min="0" max="30" type="number" class="form-control form-control-user" value="<?php echo e($calificacion->icbSuperior2stTest); ?>" id="icbSuperior2stTest" onfocusout="sumatoriaIcBs()" name="icbSuperior2stTest" placeholder="2do test">
                                        </div>
                                        <div class="col-sm-4">
                                            <input min="0" max="30" type="number" class="form-control form-control-user" value="<?php echo e($calificacion->icbSuperior3stTest); ?>" id="icbSuperior3stTest" onfocusout="sumatoriaIcBs()" name="icbSuperior3stTest" placeholder="3er test">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <div class="col-sm-6 mb-3 mb-sm-0">
                                            <input min="0" max="20" type="number" class="form-control form-control-user" value="<?php echo e($calificacion->icbSuperiorPlataformaYtareas); ?>" id="icbSuperiorPlataformaYtareas" onfocusout="sumatoriaIcBs()" name="icbSuperiorPlataformaYtareas" placeholder="Plataforma y Tareas">
                                        </div>
                                        <div class="col-sm-6 mb-3 mb-sm-0">
                                            <input readonly type="text" class="form-control form-control-user" value="<?php echo e($calificacion->icbSuperiorFinalScore); ?>" id="icbSuperiorFinalScore" onfocusout="sumatoriaIcBs()" name="icbSuperiorFinalScore" placeholder="Final Score">
                                        </div>
                                    </div>

                                    <hr>
                                    <div class="form-group row">
                                        <div class="col-sm-4 mb-3 mb-sm-0">
                                            <input type="text" class="form-control form-control-user" value="<?php echo e($calificacion->icbSuperiorParticipation); ?>" id="icbSuperiorParticipation" name="icbSuperiorParticipation" placeholder="Participation">
                                        </div>
                                        <div class="col-sm-4 mb-3 mb-sm-0">
                                            <input type="text" class="form-control form-control-user" value="<?php echo e($calificacion->icbSuperiorUnderstanding); ?>" id="icbSuperiorUnderstanding" name="icbSuperiorUnderstanding" placeholder="Understanding of concepts principles">
                                        </div>
                                        <div class="col-sm-4 mb-3 mb-sm-0">
                                            <input type="text" class="form-control form-control-user" value="<?php echo e($calificacion->icbSuperiorApplication); ?>" id="icbSuperiorApplication" name="icbSuperiorApplication" placeholder="Application of concepts">
                                        </div>
                                    </div>

                                    <div class="form-group row">
                                        <div class="col-sm-4 mb-3 mb-sm-0">
                                            <input type="text" class="form-control form-control-user" value="<?php echo e($calificacion->icbSuperiorPresentation); ?>" id="icbSuperiorPresentation" name="icbSuperiorPresentation" placeholder="Presentation Skill">
                                        </div>
                                        <div class="col-sm-4 mb-3 mb-sm-0">
                                            <input type="text" class="form-control form-control-user" value="<?php echo e($calificacion->icbSuperiorTestScore); ?>" id="icbSuperiorTestScore" name="icbSuperiorTestScore" placeholder="Test Score">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <div class="col-sm-6 mb-3 mb-sm-0">
                                            <button type="submit" class="btn btn-info" id="inglesComunicativoInicialBtn">Actualizar</button>
                                        </div>
                                    </div>
                                </div>

                            </div>
                            <div role="tabpanel" class="tab-pane" id="tab3">

                                <div class="form-group p-3">
                                    <h5>Inglés Comunicativo Pre Intermedio</h5>
                                    <div class="form-group row">
                                        <div class="col-sm-4">
                                            <input min="0" max="20" type="number" class="form-control form-control-user" value="<?php echo e($calificacion->icpIntermedio1stTest); ?>" id="icpIntermedio1stTest" onfocusout="sumatoriaIcpi()" name="icpIntermedio1stTest" placeholder="1st test">
                                        </div>
                                        <div class="col-sm-4">
                                            <input min="0" max="30" type="number" class="form-control form-control-user" value="<?php echo e($calificacion->icpIntermedio2stTest); ?>" id="icpIntermedio2stTest" onfocusout="sumatoriaIcpi()" name="icpIntermedio2stTest" placeholder="2do test">
                                        </div>
                                        <div class="col-sm-4">
                                            <input min="0" max="30" type="number" class="form-control form-control-user" value="<?php echo e($calificacion->icpIntermedio3stTest); ?>" id="icpIntermedio3stTest" onfocusout="sumatoriaIcpi()" name="icpIntermedio3stTest" placeholder="3er test">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <div class="col-sm-6 mb-3 mb-sm-0">
                                            <input min="0" max="20" type="number" class="form-control form-control-user" value="<?php echo e($calificacion->icpIntermedioPlataformaYtareas); ?>" id="icpIntermedioPlataformaYtareas" onfocusout="sumatoriaIcpi()" name="icpIntermedioPlataformaYtareas" placeholder="Plataforma y Tareas">
                                        </div>
                                        <div class="col-sm-6 mb-3 mb-sm-0">
                                            <input readonly type="text" class="form-control form-control-user" value="<?php echo e($calificacion->icpIntermedioFinalScore); ?>" id="icpIntermedioFinalScore" onfocusout="sumatoriaIcpi()" name="icpIntermedioFinalScore" placeholder="Final Score">
                                        </div>
                                    </div>

                                    <hr>
                                    <div class="form-group row">
                                        <div class="col-sm-4 mb-3 mb-sm-0">
                                            <input type="text" class="form-control form-control-user" value="<?php echo e($calificacion->icpIntermedioParticipation); ?>" id="icpIntermedioParticipation" name="icpIntermedioParticipation" placeholder="Participation">
                                        </div>
                                        <div class="col-sm-4 mb-3 mb-sm-0">
                                            <input type="text" class="form-control form-control-user" value="<?php echo e($calificacion->icpIntermedioUnderstanding); ?>" id="icpIntermedioUnderstanding" name="icpIntermedioUnderstanding" placeholder="Understanding of concepts principles">
                                        </div>
                                        <div class="col-sm-4 mb-3 mb-sm-0">
                                            <input type="text" class="form-control form-control-user" value="<?php echo e($calificacion->icpIntermedioApplication); ?>" id="icpIntermedioApplication" name="icpIntermedioApplication" placeholder="Application of concepts">
                                        </div>
                                    </div>

                                    <div class="form-group row">
                                        <div class="col-sm-4 mb-3 mb-sm-0">
                                            <input type="text" class="form-control form-control-user" value="<?php echo e($calificacion->icpIntermedioPresentation); ?>" id="icpIntermedioPresentation" name="icpIntermedioPresentation" placeholder="Presentation Skill">
                                        </div>
                                        <div class="col-sm-4 mb-3 mb-sm-0">
                                            <input type="text" class="form-control form-control-user" value="<?php echo e($calificacion->icpIntermedioTestScore); ?>" id="icpIntermedioTestScore" name="icpIntermedioTestScore" placeholder="Test Score">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <div class="col-sm-6 mb-3 mb-sm-0">
                                            <button type="submit" class="btn btn-info" id="inglesComunicativoInicialBtn">Actualizar</button>
                                        </div>
                                    </div>
                                </div>

                            </div>
                            <div role="tabpanel" class="tab-pane" id="tab4">


                                <div class="form-group p-3">
                                    <h5>Inglés Comunicativo Intermedio</h5>
                                    <div class="form-group row">
                                        <div class="col-sm-4">
                                            <input min="0" max="20" type="number" class="form-control form-control-user" value="<?php echo e($calificacion->icIntermedio1stTest); ?>" id="icIntermedio1stTest" onfocusout="sumatoriaIci()" name="icIntermedio1stTest" placeholder="1st test">
                                        </div>
                                        <div class="col-sm-4">
                                            <input min="0" max="30" type="number" class="form-control form-control-user" value="<?php echo e($calificacion->icIntermedio2stTest); ?>" id="icIntermedio2stTest" onfocusout="sumatoriaIci()" name="icIntermedio2stTest" placeholder="2do test">
                                        </div>
                                        <div class="col-sm-4">
                                            <input min="0" max="30" type="number" class="form-control form-control-user" value="<?php echo e($calificacion->icIntermedio3stTest); ?>" id="icIntermedio3stTest" onfocusout="sumatoriaIci()" name="icIntermedio3stTest" placeholder="3er test">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <div class="col-sm-6 mb-3 mb-sm-0">
                                            <input min="0" max="20" type="number" class="form-control form-control-user" value="<?php echo e($calificacion->icIntermedioPlataformaYtareas); ?>" id="icIntermedioPlataformaYtareas" onfocusout="sumatoriaIci()" name="icIntermedioPlataformaYtareas" placeholder="Plataforma y Tareas">
                                        </div>
                                        <div class="col-sm-6 mb-3 mb-sm-0">
                                            <input readonly type="text" class="form-control form-control-user" value="<?php echo e($calificacion->icIntermedioFinalScore); ?>" id="icIntermedioFinalScore" onfocusout="sumatoriaIci()" name="icIntermedioFinalScore" placeholder="Final Score">
                                        </div>
                                    </div>

                                    <hr>
                                    <div class="form-group row">
                                        <div class="col-sm-4 mb-3 mb-sm-0">
                                            <input type="text" class="form-control form-control-user" value="<?php echo e($calificacion->icIntermedioParticipation); ?>" id="icIntermedioParticipation" name="icIntermedioParticipation" placeholder="Participation">
                                        </div>
                                        <div class="col-sm-4 mb-3 mb-sm-0">
                                            <input type="text" class="form-control form-control-user" value="<?php echo e($calificacion->icIntermedioUnderstanding); ?>" id="icIntermedioUnderstanding" name="icIntermedioUnderstanding" placeholder="Understanding of concepts principles">
                                        </div>
                                        <div class="col-sm-4 mb-3 mb-sm-0">
                                            <input type="text" class="form-control form-control-user" value="<?php echo e($calificacion->icIntermedioApplication); ?>" id="icIntermedioApplication" name="icIntermedioApplication" placeholder="Application of concepts">
                                        </div>
                                    </div>

                                    <div class="form-group row">
                                        <div class="col-sm-4 mb-3 mb-sm-0">
                                            <input type="text" class="form-control form-control-user" value="<?php echo e($calificacion->icIntermedioPresentation); ?>" id="icIntermedioPresentation" name="icIntermedioPresentation" placeholder="Presentation Skill">
                                        </div>
                                        <div class="col-sm-4 mb-3 mb-sm-0">
                                            <input type="text" class="form-control form-control-user" value="<?php echo e($calificacion->icIntermedioTestScore); ?>" id="icIntermedioTestScore" name="icIntermedioTestScore" placeholder="Test Score">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <div class="col-sm-6 mb-3 mb-sm-0">
                                            <button type="submit" class="btn btn-info" id="inglesComunicativoInicialBtn">Actualizar</button>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('js/calificaciones/calificacionesEdit.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>