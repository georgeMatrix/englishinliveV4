<form class="user" action="<?php echo e(url('api/darDeBaja/'.$id)); ?>" method="get" id="formBaja<?php echo e($id); ?>">
    <?php echo e(csrf_field()); ?>

    <?php echo e(method_field('PATCH')); ?>

    <button id="btnBaja<?php echo e($id); ?>" type="submit" class="btn">Baja</button>
</form>
