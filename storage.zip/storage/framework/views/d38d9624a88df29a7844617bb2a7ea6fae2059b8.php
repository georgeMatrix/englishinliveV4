<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('include.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="text-center title">CONTROL ESCOLAR</h1>
            </div>
            <div class="col-lg-2 col-md-2 col-md-2 col-xs-2 offset-xl-10 offset-md-10 offset-xs-10 mb-3">
                <a class="btn btn-success btn-block" href="<?php echo e(route('controlEscolar.create')); ?>" >NUEVO</a>
            </div>
        </div>
        <div class="row">
                <div class="col-lg-12 col-md-12 col-xl-12">
                        <div class="table-responsive content-loader">
                            <table class="table table-hover table-sm table-striped">
                                <thead class="table-primary">
                                <tr>
                                    <th>NO.</th>
                                    <th>GRUPO</th>
                                    <th>ESCOLARIDAD</th>
                                    <th>NO_DE_CONTROL</th>
                                    <th>CICLO_ESCOLAR</th>
                                    <th>EDAD</th>
                                    <th>INCORPORADOS</th>
                                    <th>SEXO</th>
                                    <th>NIVEL</th>
                                    <th>MAESTRO</th>
                                    <th>HORARIO_SEP</th>
                                    <th>CURP</th>
                                    <th>HORARIO</th>
                                    <th>MODULOS_ACREDITADOS</th>
                                    <th>NOMBRE_COMPLETO_DEL_ALUMNO</th>
                                    <th>EDITAR</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $registros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($registro->id); ?></td>
                                        <td><?php echo e($registro->grupo); ?></td>
                                        <td><?php echo e($registro->escolaridad); ?></td>
                                        <td><?php echo e($registro->noControl); ?></td>
                                        <td><?php echo e($registro->cicloEscolar); ?></td>
                                        <td><?php echo e($registro->edad); ?></td>
                                        <td><?php echo e($registro->incorporados); ?></td>
                                        <td><?php echo e($registro->sexo); ?></td>
                                        <td><?php echo e($registro->niveles); ?></td>
                                        <td><?php echo e($registro->maestro); ?></td>
                                        <td><?php echo e($registro->horarioSep); ?></td>
                                        <td><?php echo e($registro->curp); ?></td>
                                        <td><?php echo e($registro->horario); ?></td>
                                        <td><?php echo e($registro->modulosAcreditados); ?></td>
                                        <td><?php echo e($registro->nombreCompleto); ?></td>
                                        <td><a href="<?php echo e(route('controlEscolar.edit', $registro->id)); ?>" class="btn btn-info">Editar</a></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                                <?php echo e($registros->render()); ?>

                            </table>
                        </div>
                </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>