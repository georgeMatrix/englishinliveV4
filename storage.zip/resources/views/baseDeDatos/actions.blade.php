<a href="{{ route('baseDeDatos.edit', $id) }}" class="btn btn-primary btn-sm"><i class="far fa-edit"></i></a>
